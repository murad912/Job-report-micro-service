package com.jobReport.jobReport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
